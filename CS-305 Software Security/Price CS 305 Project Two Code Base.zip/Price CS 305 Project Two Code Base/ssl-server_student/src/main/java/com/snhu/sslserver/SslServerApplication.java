package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import java.security.MessageDigest;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController{

	@GetMapping("/hash")
	public String greeting (@RequestParam(value = "name", defaultValue = "Romi'on Price") String name) 
		throws Exception{
		return myHash(name);
	}
    @RequestMapping("/hash")
    public String myHash(String data) throws Exception{
       MessageDigest md = MessageDigest.getInstance("SHA-256");
       md.update(data.getBytes());
       
       byte[] digest = md.digest();
       
       StringBuffer hexString = new StringBuffer();
       
    	for (int i = 0; i < digest.length; i++) {
    		hexString.append(Integer.toHexString(0xff & digest[i]));
    	}
    	
    	String returnString = String.format("<p> data: Hello %s!", data);
    	returnString += "<p>Name of cipher used: SHA-256";
    	returnString += "<p>SHA-256 : CheckSum Value:";
        return returnString + hexString;
        
    }
    
}
